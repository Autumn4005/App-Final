package com.example.midterm1121204

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
